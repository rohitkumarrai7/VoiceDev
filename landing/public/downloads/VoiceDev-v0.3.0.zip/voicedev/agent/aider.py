import os
import re
import shutil
import subprocess
import sys
import threading
import time
from typing import List, Optional

from voicedev.agent.base import AgentBackend

try:
    import pexpect
    PEXPECT_AVAILABLE = True
except ImportError:
    PEXPECT_AVAILABLE = False


class AiderBackend(AgentBackend):
    PROMPT_PATTERNS = [
        re.compile(r"Accept this change\?", re.IGNORECASE),
        re.compile(r"Add .* to the chat\?", re.IGNORECASE),
        re.compile(r"Run shell command\?", re.IGNORECASE),
        re.compile(r"Undo that change\?", re.IGNORECASE),
        re.compile(r"\(Y/n", re.IGNORECASE),
        re.compile(r"\(y/N", re.IGNORECASE),
        re.compile(r"\[Y/n", re.IGNORECASE),
        re.compile(r"\[y/N", re.IGNORECASE),
        re.compile(r"\[Yes/No", re.IGNORECASE),
        re.compile(r"\[Yes/no/all", re.IGNORECASE),
        re.compile(r"Add \.aider\* to \.gitignore", re.IGNORECASE),
    ]

    MAX_RESTARTS = 3
    RESTART_BACKOFF_BASE = 2.0

    def __init__(self, extra_args: Optional[List[str]] = None, auto_restart: bool = True):
        self._extra_args = extra_args or []
        self._child = None
        self._process: Optional[subprocess.Popen] = None
        self._reader_thread: Optional[threading.Thread] = None
        self._running = False
        self._lock = threading.Lock()
        self._pending_prompt: Optional[str] = None
        self._output_buffer: List[str] = []
        self._use_pexpect = False
        self._is_windows = sys.platform == "win32"
        self._auto_restart = auto_restart
        self._restart_count = 0
        self._last_start_time = 0.0
        self._on_restart_cb = None

    def set_on_restart(self, callback) -> None:
        self._on_restart_cb = callback

    @staticmethod
    def _resolve_aider_path() -> Optional[str]:
        for name in ["aider", "aider.exe", "aider.bat", "aider.cmd"]:
            path = shutil.which(name)
            if path:
                return path

        uv_bin = os.path.join(os.path.expanduser("~"), ".local", "bin")
        for name in ["aider", "aider.exe", "aider.bat"]:
            candidate = os.path.join(uv_bin, name)
            if os.path.exists(candidate):
                return candidate

        scripts_dir = os.path.join(os.path.dirname(sys.executable), "Scripts")
        for name in ["aider.exe", "aider.bat", "aider.cmd"]:
            candidate = os.path.join(scripts_dir, name)
            if os.path.exists(candidate):
                return candidate

        try:
            result = subprocess.run(
                [sys.executable, "-m", "aider", "--version"],
                capture_output=True, text=True, timeout=10,
            )
            if result.returncode == 0:
                return sys.executable
        except Exception:
            pass

        return None

    def _build_cmd(self, aider_path: str) -> List[str]:
        if aider_path == sys.executable:
            base = [sys.executable, "-m", "aider"]
        else:
            base = [aider_path]

        auto_flags = [
            "--no-pretty", "--no-gitignore", "--no-auto-commits",
            "--yes-always", "--map-tokens", "256", "--no-auto-lint",
        ]
        for flag in auto_flags:
            if flag not in self._extra_args:
                base.append(flag)

        voicedev_model = os.environ.get("VOICEDEV_AIDER_MODEL", "").strip()
        model_in_extra = any(arg.startswith("--model") for arg in self._extra_args)
        requested_model = "" if model_in_extra else voicedev_model

        minimax_key = os.environ.get("MINIMAX_API_KEY", "")
        explicit_minimax_model = (
            any("minimax" in arg.lower() for arg in self._extra_args)
            or "minimax" in requested_model.lower()
        )
        minimax_env_enabled = os.environ.get("VOICEDEV_USE_MINIMAX", "").lower() in {
            "1", "true", "yes", "on",
        }
        use_minimax = bool(minimax_key and (explicit_minimax_model or minimax_env_enabled))

        if use_minimax:
            base.extend(["--openai-api-key", minimax_key])
            base.extend(["--openai-api-base", "https://api.minimaxi.chat/v1"])

        if not model_in_extra:
            if requested_model:
                base.extend(["--model", requested_model])
            elif use_minimax:
                base.extend(["--model", "minimax/minimax-m2.5"])

        base.extend(self._extra_args)
        return base

    def start(self) -> None:
        self._last_start_time = time.time()
        aider_path = self._resolve_aider_path()

        if aider_path is None:
            print("\n[VoiceDev] WARNING: 'aider' not found.")
            print("[VoiceDev] Install with: pip install aider-chat  OR  uv tool install aider-chat")
            print("[VoiceDev] Running in echo mode — voice input will be displayed but not sent to an agent.\n")
            self._running = True
            return

        if self._is_windows:
            self._start_windows_mode(aider_path)
        elif PEXPECT_AVAILABLE:
            self._start_with_pexpect(aider_path)
        else:
            self._start_with_subprocess(aider_path)

    def _start_windows_mode(self, aider_path: str) -> None:
        cmd = self._build_cmd(aider_path)
        cmd_str = " ".join(f'"{c}"' if " " in c else c for c in cmd)
        print(f"[VoiceDev] Launching: {cmd_str}")

        try:
            env = os.environ.copy()
            env["PYTHONIOENCODING"] = "utf-8"
            env["TERM"] = "dumb"

            self._process = subprocess.Popen(
                cmd,
                stdin=subprocess.PIPE,
                stdout=None,
                stderr=None,
                text=True,
                creationflags=subprocess.CREATE_NEW_PROCESS_GROUP,
                env=env,
            )
            self._running = True
            self._use_pexpect = False

            self._reader_thread = threading.Thread(target=self._watchdog_windows, daemon=True)
            self._reader_thread.start()

            time.sleep(2.0)
            print(f"[VoiceDev] Aider started (PID {self._process.pid})")

        except Exception as e:
            print(f"[VoiceDev] ERROR launching aider: {e}")
            self._running = True

    def _watchdog_windows(self) -> None:
        if self._process is None:
            return
        try:
            self._process.wait()
        except Exception:
            pass

        if self._auto_restart and self._attempt_restart():
            return

        self._running = False
        print("\n[VoiceDev] Aider process exited.")

    def _start_with_pexpect(self, aider_path: str) -> None:
        cmd_list = self._build_cmd(aider_path)
        cmd_str = subprocess.list2cmdline(cmd_list)

        try:
            self._child = pexpect.spawn(
                cmd_str, timeout=None, encoding="utf-8", codec_errors="replace"
            )
            self._running = True
            self._use_pexpect = True

            self._reader_thread = threading.Thread(target=self._read_output_pexpect, daemon=True)
            self._reader_thread.start()
            time.sleep(1.5)

            pid = getattr(self._child, "pid", "unknown")
            print(f"[VoiceDev] Aider started (PID {pid}, pexpect/PTY mode)")
        except Exception as e:
            print(f"[VoiceDev] pexpect failed ({e}), falling back to subprocess...")
            self._start_with_subprocess(aider_path)

    def _read_output_pexpect(self) -> None:
        try:
            while self._running and self._child is not None:
                try:
                    self._child.expect(r"\r?\n", timeout=0.5)
                    line = (self._child.before or "").strip()
                except pexpect.TIMEOUT:
                    continue
                except pexpect.EOF:
                    break
                except Exception:
                    time.sleep(0.1)
                    continue

                if line:
                    with self._lock:
                        self._output_buffer.append(line)
                        if len(self._output_buffer) > 200:
                            self._output_buffer = self._output_buffer[-200:]
                    print(line, flush=True)
                    self._detect_prompt(line)
        except Exception:
            pass
        finally:
            restarted = self._auto_restart and self._attempt_restart()
            if not restarted:
                self._running = False
                print("[VoiceDev] Aider process exited.")

    def _start_with_subprocess(self, aider_path: str) -> None:
        cmd = self._build_cmd(aider_path)

        try:
            self._process = subprocess.Popen(
                cmd,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                bufsize=1,
                text=True,
            )
            self._running = True
            self._use_pexpect = False

            self._reader_thread = threading.Thread(target=self._read_output_subprocess, daemon=True)
            self._reader_thread.start()

            print(f"[VoiceDev] Aider started (PID {self._process.pid}, subprocess mode)")
        except FileNotFoundError:
            print("[VoiceDev] ERROR: Could not launch aider.")
            self._running = True

    def _read_output_subprocess(self) -> None:
        try:
            while self._running and self._process is not None:
                line = self._process.stdout.readline()
                if not line:
                    if self._process.poll() is not None:
                        break
                    time.sleep(0.1)
                    continue
                line = line.strip()
                if line:
                    with self._lock:
                        self._output_buffer.append(line)
                        if len(self._output_buffer) > 200:
                            self._output_buffer = self._output_buffer[-200:]
                    print(line, flush=True)
                    self._detect_prompt(line)
        except Exception:
            pass
        finally:
            restarted = self._auto_restart and self._attempt_restart()
            if not restarted:
                self._running = False
                print("[VoiceDev] Aider process exited.")

    def _attempt_restart(self) -> bool:
        uptime = time.time() - self._last_start_time
        if uptime < 5.0:
            return False
        if self._restart_count >= self.MAX_RESTARTS:
            print(f"[VoiceDev] Aider crashed {self._restart_count} times. Giving up.")
            return False

        self._restart_count += 1
        delay = self.RESTART_BACKOFF_BASE ** self._restart_count
        print(f"[VoiceDev] Aider exited unexpectedly. Restarting in {delay:.0f}s "
              f"(attempt {self._restart_count}/{self.MAX_RESTARTS})...")
        time.sleep(delay)

        if self._on_restart_cb:
            try:
                self._on_restart_cb(self._restart_count)
            except Exception:
                pass

        self._process = None
        self._child = None
        self.start()
        return self._running

    def _detect_prompt(self, line: str) -> None:
        for pattern in self.PROMPT_PATTERNS:
            if pattern.search(line):
                with self._lock:
                    self._pending_prompt = line
                return

    def has_pending_prompt(self) -> Optional[str]:
        with self._lock:
            return self._pending_prompt

    def respond_to_prompt(self, response: str) -> None:
        with self._lock:
            self._pending_prompt = None

        normalized = response.lower().strip()
        if normalized in ("yes", "yep", "yeah", "sure", "accept", "ok"):
            response = "y"
        elif normalized in ("no", "nope", "nah", "reject", "deny"):
            response = "n"
        elif normalized in ("all", "accept all"):
            response = "a"
        elif normalized in ("skip",):
            response = "s"

        self._send_raw(response)

    def clear_pending_prompt(self) -> None:
        with self._lock:
            self._pending_prompt = None

    def send_query(self, text: str) -> None:
        if not self._running:
            print(f"[VoiceDev] (echo) {text}")
            return
        self._send_raw(text)

    def send_command(self, command: str) -> None:
        if not command.startswith("/"):
            command = "/" + command
        self.send_query(command)

    def _send_raw(self, text: str) -> None:
        try:
            if self._use_pexpect and self._child is not None:
                self._child.sendline(text)
            elif self._process is not None and self._process.stdin is not None:
                self._process.stdin.write(text + "\n")
                self._process.stdin.flush()
            else:
                print(f"[VoiceDev] (echo) {text}")
        except (BrokenPipeError, OSError, ValueError) as e:
            print(f"[VoiceDev] ERROR sending to aider: {e}")
            self._running = False

    def stop(self) -> None:
        self._auto_restart = False
        self._running = False
        self.clear_pending_prompt()

        if self._use_pexpect and self._child is not None:
            try:
                self._child.sendline("/exit")
                time.sleep(0.5)
            except Exception:
                pass
            try:
                self._child.terminate(force=True)
            except Exception:
                pass
            try:
                self._child.close(force=True)
            except Exception:
                pass
            self._child = None

        if self._process is not None:
            try:
                if self._process.stdin is not None:
                    self._process.stdin.write("/exit\n")
                    self._process.stdin.flush()
                    time.sleep(0.5)
            except (BrokenPipeError, OSError):
                pass
            try:
                if self._is_windows:
                    subprocess.run(
                        ["taskkill", "/PID", str(self._process.pid), "/T", "/F"],
                        capture_output=True, timeout=5,
                    )
                else:
                    self._process.terminate()
                    self._process.wait(timeout=3)
            except Exception:
                pass
            self._process = None

    def is_running(self) -> bool:
        return self._running
